# 🌈 Psychedelic M5 Screensavers

**The ultimate collection of 28 mesmerizing screensavers for M5StickC Plus2**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Platform: ESP32](https://img.shields.io/badge/Platform-ESP32-blue.svg)](https://www.espressif.com/en/products/socs/esp32)
[![Device: M5StickC Plus2](https://img.shields.io/badge/Device-M5StickC%20Plus2-red.svg)](https://docs.m5stack.com/en/core/M5StickC%20PLUS2)
[![PlatformIO](https://img.shields.io/badge/Built%20with-PlatformIO-orange.svg)](https://platformio.org/)

Transform your M5StickC Plus2 into a **portable consciousness visualizer** with 28 mathematically beautiful, psychedelic screensavers featuring fractals, particle systems, and mind-bending animations.

## 🚀 **Quick Start (30 seconds)**

### 🔥 **Option 1: Flash Pre-built Firmware (Easiest)**
1. Download [`Psychedelic-M5v1.1.bin`](firmware/Psychedelic-M5v1.1.bin)
2. Flash with [M5Burner](https://docs.m5stack.com/en/download)
3. **Enjoy 28 screensavers immediately!**

### 🛠️ **Option 2: Build from Source**
```bash
git clone https://github.com/your-repo/Psychedelic-M5-Screensavers.git
cd Psychedelic-M5-Screensavers
pio run --target upload
```

## 🎮 **Controls (v1.1)**

| Button | Function | Details |
|--------|----------|---------|
| **BtnA** | 🎛️ Speed Control | 10 levels: slow meditation → fast psychedelic |
| **BtnB** | ➡️ Next Screensaver | Forward navigation through all 28 |
| **BtnC** | ⬅️ Previous Screensaver | Backward navigation |

## 🎨 **28 Incredible Screensavers**

### 🧠 **Consciousness & AI**
- **🌟 Digital Dreams** - Visualization of thought connections and consciousness
- **🔗 Neural Networks** - Brain-inspired particle interactions

### 🔬 **Mathematical Fractals**
- **🌀 Julia Set** - Complex number fractal mathematics
- **🗻 Mandelbrot** - Classic fractal zoom with infinite detail
- **🐉 Dragon Curve** - Recursive line folding patterns
- **🔺 Sierpinski Triangle** - Self-similar triangle fractals
- **📐 Spirograph** - Mathematical curve art

### 🌊 **Plasma & Wave Effects**
- **🌈 Plasma Waves** - Sine wave interference patterns
- **💫 Flow Field** - Particle dynamics simulation
- **✨ Color Shimmer** - Dynamic rainbow fields

### 🎭 **Classic Screensaver Effects**
- **💚 Matrix Binary** - Falling code rain
- **🔮 Kaleidoscope** - Symmetric pattern generation
- **⭐ Starfield Warp** - Star tunnel effect
- **🚶 Walking Shapes** - Trail-leaving geometric forms

### 🌧️ **Particle Systems**
- **🌈 Neon Rain** - Colorful falling particles
- **⛈️ Heavy Rain** - Intense precipitation effects
- **🧚 Firefly Swarm** - Organic movement patterns
- **💧 Raindrops** - Realistic water simulation

### 🔥 **Natural Phenomena**
- **🔥 Campfire** - Realistic flame simulation
- **🌊 Liquid Metal** - Flowing metallic effects
- **📍 Micro Dots** - Particle field animations

### 🎪 **Geometric Art**
- **🔄 Retro Geometry** - 80s-style patterns
- **🔄 Recursive Polygons** - Self-similar shapes
- **🌀 Simple Flames** - Fire effect visualization

## 📁 **Project Structure**

```
Psychedelic-M5-Screensavers/
├── 🗂️ firmware/           # Ready-to-flash .bin files
│   ├── Psychedelic-M5v1.1.bin    # Latest with advanced controls
│   ├── Psychedelic-M5v1.0.bin    # Stable original
│   └── M5Burner_config.json      # M5Burner metadata
├── 🗂️ src/               # Source code
│   └── main.cpp                  # Complete implementation
├── 🗂️ docs/              # Documentation
├── 🗂️ screensavers/      # Original Python examples
├── 🗂️ examples/          # Usage examples
├── platformio.ini        # PlatformIO configuration
├── README.md            # This file
└── LICENSE              # MIT License
```

## 🛠️ **Development**

### **Requirements**
- [PlatformIO IDE](https://platformio.org/install/ide?install=vscode)
- M5StickC Plus2 hardware
- USB-C cable

### **Build Commands**
```bash
# Build firmware
pio run

# Upload to device  
pio run --target upload

# Monitor serial output
pio device monitor
```

### **Adding New Screensavers**
See [CONTRIBUTING.md](CONTRIBUTING.md) for detailed guidelines on:
- Creating new screensaver functions
- Performance optimization tips
- Mathematical implementation patterns
- Testing procedures

## 📱 **Device Compatibility**

| Device | Status | Notes |
|--------|--------|-------|
| **M5StickC Plus2** | ✅ **Perfect** | Primary target, fully optimized |
| M5StickC Plus | 🔶 **Untested** | Should work with minor changes |
| Other M5Stack | ❓ **Unknown** | Display size differences |

**Memory Usage**: RAM: 10.4%, Flash: 37.7% (efficient!)

## 🎯 **Perfect For**

- 🎨 **Art Installations** - Museum-quality visual displays
- 🧘 **Meditation Aids** - Calming visual focus points
- 🎓 **Education** - Mathematical concept visualization
- 🎉 **Entertainment** - Party ambiance and conversation starters
- 🔬 **Demos** - Showcase embedded graphics capabilities
- 💻 **Desk Decoration** - Endless visual variety

## 📋 **Version History**

### **v1.1** - Enhanced Control ⭐ *Current*
- ✅ Advanced 3-button navigation system
- ✅ 10-level speed adjustment (0.1x to 2.5x)
- ✅ Professional button debouncing
- ✅ Clean immersive interface

### **v1.0** - Original Release
- ✅ 28 unique screensavers
- ✅ Basic navigation controls
- ✅ Proven stability

## 🌟 **Community**

### **Contributing**
We welcome contributions! See [CONTRIBUTING.md](CONTRIBUTING.md) for:
- Adding new screensavers
- Performance improvements  
- Documentation enhancements
- Bug fixes

### **Support**
- 🐛 **Bug Reports**: Use GitHub Issues
- 💡 **Feature Requests**: Use GitHub Discussions  
- 📚 **Documentation**: Check the `docs/` folder
- 💬 **Community**: Join the conversation

## 📄 **License**

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 **Acknowledgments**

- **M5Stack** for amazing hardware
- **PlatformIO** for excellent development tools
- **ESP32 Community** for optimization techniques
- **Mathematics Community** for beautiful algorithms
- **Psychedelic Art Community** for inspiration

## 🌈 **Gallery**

*Screenshots and videos of the screensavers in action would go here*

---

### 🚀 **Ready to Experience Digital Consciousness?**

**Download, flash, and transform your M5StickC Plus2 into a portable psychedelic art generator!**

*The most comprehensive screensaver collection ever created for M5Stack devices* ✨

[![Download Latest Release](https://img.shields.io/badge/Download-Latest%20Release-green.svg?style=for-the-badge)](firmware/Psychedelic-M5v1.1.bin)