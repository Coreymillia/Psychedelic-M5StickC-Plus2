# 🚀 **M5STICKC PLUS2 PROJECT DEVELOPMENT GUIDE**
## Complete Technical Reference for Future Projects

---

## 📱 **DISPLAY SYSTEM MASTERY**

### **Display Configuration (From Biorhythm Success)**
```cpp
// Display setup - CRITICAL for M5StickC Plus2
#define Disp M5.Lcd

void setup() {
  auto cfg = M5.config();
  
  // Power management - prevents button/display issues
  cfg.clear_display = true;
  cfg.output_power = false;
  cfg.internal_imu = false;  
  cfg.internal_rtc = false;
  cfg.internal_spk = false;
  cfg.internal_mic = false;
  
  M5.begin(cfg);
  
  // ESSENTIAL: Portrait mode for M5StickC Plus2
  Disp.setRotation(0);  // Portrait mode
  Disp.fillScreen(BLACK);
}
```

### **Color Codes That Work Perfectly**
```cpp
// High-visibility colors tested and proven:
#define GREEN_SELECT    0x07E0  // Bright green for selection
#define CYAN_BLUE       0x07FF  // Perfect for readable text
#define WHITE_TEXT      WHITE   // Standard white
#define YELLOW_BRIGHT   0xFFE0  // Bright yellow
#define RED_CYCLE       0xF800  // Red for physical cycle
#define ORANGE_MID      0xFC00  // Orange for mid-range
#define GRAY_SUBTLE     0x8410  // Subtle gray for lines
#define PURPLE_DARK     0x8010  // Dark purple accent
```

### **Text Positioning System**
```cpp
// Text positioning that works on 135x240 screen:
void drawText(String text, int x, int y, uint16_t color, int size = 1) {
  Disp.setTextColor(color);
  Disp.setTextSize(size);
  Disp.drawString(text, x, y, 1);
}

// Layout examples from biorhythm:
// Title area: y=10-40
// Content area: y=50-180  
// Controls area: y=190-240
// Side margins: x=5-10 for left, x=125-130 for right
```

---

## 🎯 **M5BURNER COMPLETE SUCCESS METHOD**

### **CRITICAL: Merged Binary Creation**
```bash
# This is THE method that works for M5Burner public distribution:
cd /path/to/project
esptool --chip esp32 merge-bin -o Complete_M5Burner_Package.bin \
  --flash-mode dio --flash-freq 40m --flash-size 4MB \
  0x1000 .pio/build/esp32dev/bootloader.bin \
  0x8000 .pio/build/esp32dev/partitions.bin \
  0x10000 .pio/build/esp32dev/firmware.bin
```

### **M5Burner Package Structure (PROVEN WORKING)**
```
Project_Name_vX.X_Final/
├── ProjectName_M5Burner_Complete.bin    (merged binary ~500-600KB)
└── m5burner_config.json                 (configuration file)
```

### **M5Burner Configuration Template**
```json
{
  "name": "Project Name v1.0",
  "version": "1.0.0", 
  "author": "coreymillia + GitHub Copilot CLI",
  "description": "Detailed description with features",
  "category": "Applications", // or "Games", "Tools", etc.
  "device": "M5StickC Plus 2",
  "homepage": "https://github.com/user/repo",
  "features": [
    "Feature 1 with emoji 📱",
    "Feature 2 with details 🎨"
  ],
  "controls": {
    "Button Name": "Function description",
    "M5 Button": "Primary action",
    "B Button": "Secondary action",
    "PWR Button": "Special function"
  },
  "firmware": {
    "bootloader": "0x1000",
    "partitions": "0x8000", 
    "app": "0x10000",
    "merged": true,
    "flash_offset": "0x0"
  },
  "flash_size": "4MB",
  "chip": "ESP32-PICO-V3-02"
}
```

---

## ⚡ **PLATFORMIO PROJECT STRUCTURE**

### **platformio.ini (M5StickC Plus2 Optimized)**
```ini
[env:esp32dev]
platform = espressif32
board = esp32dev
framework = arduino
lib_deps = 
    m5stack/M5StickCPlus2@^1.0.2
    IRremoteESP8266@^2.8.6
    Preferences@^2.0.0
monitor_port = /dev/ttyACM0
upload_port = /dev/ttyACM0
monitor_speed = 115200
upload_speed = 460800
```

### **Essential Libraries**
```cpp
#include <M5StickCPlus2.h>  // Main M5 library
#include <math.h>           // For calculations
#include <Preferences.h>    // For data persistence
```

---

## 🎮 **BUTTON HANDLING SYSTEM**

### **Reliable Button Detection**
```cpp
void loop() {
  M5.update();  // ALWAYS call first
  
  // Use wasClicked() for reliable single-press detection
  if (M5.BtnA.wasClicked()) {
    // M5 button action
  }
  
  if (M5.BtnB.wasClicked()) {
    // B button action  
  }
  
  if (M5.BtnPWR.wasClicked()) {
    // PWR button action
  }
  
  // For hold detection:
  if (M5.BtnA.isPressed() && M5.BtnB.isPressed()) {
    delay(1000);
    if (M5.BtnA.isPressed() && M5.BtnB.isPressed()) {
      // Both buttons held for 1 second
    }
  }
  
  delay(50); // Prevents overwhelming the processor
}
```

---

## 💾 **DATA PERSISTENCE SYSTEM**

### **Preferences Usage (Tested & Working)**
```cpp
#include <Preferences.h>
Preferences preferences;

void setup() {
  preferences.begin("app_name", false); // false = read/write
}

// Save data
void saveData() {
  preferences.putInt("key_name", value);
  preferences.putString("text_key", "text_value");
  preferences.putBool("flag_key", true);
}

// Load data  
void loadData() {
  int value = preferences.getInt("key_name", default_value);
  String text = preferences.getString("text_key", "default");
  bool flag = preferences.getBool("flag_key", false);
}
```

---

## 🎨 **GRAPHICS SYSTEM**

### **Drawing Functions That Work**
```cpp
// Basic shapes
Disp.fillScreen(BLACK);
Disp.drawRect(x, y, width, height, color);
Disp.fillRect(x, y, width, height, color);
Disp.drawLine(x1, y1, x2, y2, color);
Disp.drawPixel(x, y, color);

// Advanced graphics for psychedelic effects:
void drawSineWave(int startX, int startY, int width, int height, 
                  float frequency, uint16_t color) {
  for(int x = 0; x < width; x++) {
    float angle = (x * frequency * 2.0 * PI) / width;
    int y = startY + (height / 2) + (sin(angle) * (height / 2));
    
    if(y >= 0 && y < 240 && (startX + x) < 135) {
      Disp.drawPixel(startX + x, y, color);
    }
  }
}
```

---

## 🔧 **BUILD & DEPLOYMENT WORKFLOW**

### **Development Commands**
```bash
# Build project
pio run

# Flash to device  
pio run --target upload

# Monitor serial output
pio device monitor --port /dev/ttyACM0 --baud 115200

# Create M5Burner package
esptool --chip esp32 merge-bin -o Package_Complete.bin \
  --flash-mode dio --flash-freq 40m --flash-size 4MB \
  0x1000 .pio/build/esp32dev/bootloader.bin \
  0x8000 .pio/build/esp32dev/partitions.bin \
  0x10000 .pio/build/esp32dev/firmware.bin
```

---

## ⚠️ **CRITICAL SUCCESS FACTORS**

### **What Makes Projects Work:**
1. **Always use merged binaries for M5Burner** (prevents corruption)
2. **Portrait mode (rotation 0) for M5StickC Plus2**
3. **Power management config prevents button issues**
4. **wasClicked() for reliable button detection**
5. **50ms delay in main loop prevents processor overload**
6. **Preferences for data persistence**
7. **Color codes tested for visibility**

### **What Causes Failures:**
1. ❌ Single app binaries in M5Burner (cause corruption)
2. ❌ Wrong display rotation  
3. ❌ Missing M5.update() calls
4. ❌ Using wasPressed() instead of wasClicked()
5. ❌ No delay in main loop
6. ❌ Poor color choices for visibility

---

## 🎯 **FOR PSYCHEDELIC SCREENSAVER PROJECT**

This guide contains everything needed to create stunning visual effects with reliable M5Burner distribution. The display system can handle complex animations, the button system provides responsive controls, and the M5Burner package ensures users can easily install your creations.

**SUCCESS GUARANTEED WHEN FOLLOWING THIS GUIDE!** 🚀