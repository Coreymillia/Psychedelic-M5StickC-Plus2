# Psychedelic M5 Screensavers for M5Burner

## 🌈 Description
The ultimate collection of 28 psychedelic screensavers for M5StickC Plus2. Features mathematical visualizations, classic screensaver effects, and mesmerizing animations.

## 🎮 Controls (v1.1)
- **BtnA (Face Button)**: Speed Control (10 levels: slow → fast)
- **BtnB (Side Button)**: Next Screensaver
- **BtnC (Power Button)**: Previous Screensaver

## 🎨 Included Screensavers
1. **Digital Dreams** - Consciousness visualization with connecting nodes
2. **Plasma Waves** - Mathematical sine wave patterns
3. **Spiral Colors** - Rotating color spirals
4. **Bouncing Balls** - Physics-based ball animation
5. **Neon Rain** - Matrix-style falling particles
6. **Kaleidoscope** - Symmetric pattern generator
7. **Liquid Metal** - Flowing metallic effects
8. **Campfire** - Flickering flame simulation
9. **Dragon Curve** - Fractal curve animation
10. **Glyph Rain** - Symbol precipitation
11. **Heavy Rain** - Intense particle effects
12. **Julia Set** - Mathematical fractal visualization
13. **Mandelbrot** - Classic fractal zoom
14. **Matrix Binary** - Binary code rain
15. **Micro Dots** - Particle field animation
16. **Raindrops** - Water drop simulation
17. **Retro Geometry** - 80s-style geometric patterns
18. **Sierpinski** - Triangle fractal
19. **Simple Flames** - Fire effect
20. **Walking Triangle** - Shape trail effect
21. **Walking Square** - Geometric trail pattern
22. **Walking Star** - Star trail animation
23. **Spirograph** - Mathematical curve drawing
24. **Recursive Polygons** - Self-similar geometric patterns
25. **Flow Field** - Particle flow visualization
26. **Color Shimmer** - Dynamic color field
27. **Starfield Warp** - Star tunnel effect
28. **Firefly Swarm** - Organic particle movement

## 📱 Device Compatibility
- **Target Device**: M5StickC Plus2
- **Memory Usage**: RAM: 10.4%, Flash: 37.7%
- **Performance**: Optimized for smooth 60fps animation

## 🔧 M5Burner Configuration
- **Board**: ESP32 Dev Module
- **Flash Size**: 4MB
- **Partition Scheme**: Default
- **Upload Speed**: 921600

## 🌟 Features
- 28 unique screensavers
- 10-level speed control
- Seamless navigation
- Immersive full-screen experience
- Mathematical precision
- Optimized performance

## 📋 Version History
- **v1.0**: Initial release with 28 screensavers
- **v1.1**: Added advanced button controls and speed adjustment

## 🎯 Installation
1. Download the appropriate .bin file for your version
2. Use M5Burner to flash to your M5StickC Plus2
3. Enjoy the psychedelic experience!

---
*Created with love for the M5Stack community* 🌈✨