# 🚀 Quick Start Examples

## 🔥 **1. Flash Pre-built Firmware (30 seconds)**

### **Requirements:**
- M5StickC Plus2 device
- [M5Burner](https://docs.m5stack.com/en/download) software
- USB-C cable

### **Steps:**
1. **Download** firmware file:
   ```
   firmware/Psychedelic-M5v1.1.bin
   ```

2. **Open M5Burner** and select your device

3. **Choose** the .bin file

4. **Flash** to device

5. **Enjoy** 28 screensavers!

## 🛠️ **2. Build from Source (5 minutes)**

### **Requirements:**
- [PlatformIO IDE](https://platformio.org/install/ide?install=vscode)
- Git

### **Commands:**
```bash
# Clone repository
git clone https://github.com/your-repo/Psychedelic-M5-Screensavers.git
cd Psychedelic-M5-Screensavers

# Build and upload
pio run --target upload

# Monitor output (optional)
pio device monitor
```

## 🎮 **3. Basic Controls**

Once running on your device:

| Button | Action | What Happens |
|--------|--------|--------------|
| **BtnA** | Press | Cycle through speed: 1→2→3...→10→1 |
| **BtnB** | Press | Next screensaver: Digital Dreams→Plasma→... |
| **BtnC** | Press | Previous screensaver: ...→Plasma→Digital Dreams |

## 🎨 **4. Creating Your Own Screensaver**

### **Simple Example:**
```cpp
void drawMyScreensaver() {
  static float angle = 0;
  
  // Clear screen
  Disp.fillScreen(BLACK);
  
  // Draw rotating circle
  int centerX = SCREEN_WIDTH / 2;
  int centerY = SCREEN_HEIGHT / 2;
  int radius = 30 + sin(angle) * 20;
  
  // HSV color cycling
  uint32_t color = Disp.color565(
    HSVtoRGB((int)(angle * 180 / PI) % 360, 255, 255)
  );
  
  Disp.drawCircle(centerX, centerY, radius, color);
  
  angle += 0.1 * getSpeedMultiplier();
}
```

### **Add to Mode List:**
1. Add to enum: `MY_SCREENSAVER`
2. Add to switch statement in `loop()`
3. Compile and test!

## 📊 **5. Performance Tips**

### **Optimization Guidelines:**
- Use integer math when possible
- Implement lookup tables for trigonometry
- Avoid dynamic memory allocation
- Keep frame rates smooth (aim for 60fps)

### **Memory Monitoring:**
```bash
# Check memory usage during build
pio run --verbose

# Monitor real-time usage
pio device monitor
```

## 🐛 **6. Troubleshooting**

### **Common Issues:**

| Problem | Solution |
|---------|----------|
| **Device not found** | Check USB cable, install drivers |
| **Build errors** | Update PlatformIO, check dependencies |
| **Slow performance** | Reduce complexity, optimize math |
| **Screen flicker** | Check frame rate, reduce updates |

### **Debug Commands:**
```bash
# Clean build
pio run --target clean
pio run

# Verbose output
pio run --verbose

# Check device
pio device list
```

## 📱 **7. Advanced Configuration**

### **Custom Speed Levels:**
Edit `speedMultiplier` array in main.cpp:
```cpp
float speedMultipliers[] = {0.1, 0.2, 0.5, 1.0, 2.0};
```

### **Custom Button Mapping:**
Modify button handling in `loop()`:
```cpp
if (M5.BtnA.wasClicked()) {
  // Your custom action
}
```

## 🌟 **8. Next Steps**

- **Explore** all 28 screensavers
- **Experiment** with speed settings
- **Create** your own screensaver
- **Share** with the community
- **Contribute** improvements

---

**Ready to dive deeper? Check out the full documentation in the `docs/` folder!** 📚✨