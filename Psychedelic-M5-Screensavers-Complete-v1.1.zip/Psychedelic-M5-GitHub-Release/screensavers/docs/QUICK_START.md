# 🖥️ Waveshare LCD Screensaver Manager - Quick Start

## 🚀 How to Use

### Launch the Manager
```bash
cd /home/coreymillia/Documents/complete-projects/screensavers
./saver
```

Or:
```bash
python3 screensaver_manager.py
```

## 📋 Quick Commands

### Run Specific Screensaver Directly
```bash
./saver 1          # Run fixed matrix rain
./saver 15         # Run retro geometry
```

### Most Important Numbers

| Number | Action | Description |
|--------|--------|-------------|
| **1** | Fixed Matrix Rain | 🟢 **RECOMMENDED** - Stable, memory-safe |
| **80** | Simple Button Switcher | 🕹️ Physical button controls |
| **90** | Setup Stable Service | 🔒 Auto-start fixed matrix rain on boot |
| **93** | Check Status | 📊 See what's currently running |
| **94** | Fix GPIO Conflicts | 🔧 **Fix "GPIO busy" errors** |
| **99** | Test Mode | 🧪 Test any screensaver for 30 seconds |
| **0** | Exit | 👋 Quit the manager |

## 🎯 Recommended Setup for Your Issue

1. **Test the fix first:**
   ```bash
   ./saver
   # Choose 99, then choose 1 (tests fixed matrix rain)
   ```

2. **If it works well, set up the stable service:**
   ```bash
   ./saver
   # Choose 90 (Setup Stable Service)
   ```

3. **Check it's working:**
   ```bash
   ./saver
   # Choose 93 (Check Service Status)
   ```

## 🔧 Service Management

- **90**: Lock to stable matrix rain (fixes your 15-minute freeze issue)
- **91**: Random screensaver rotation (original system, may freeze)
- **92**: Disable all auto-start screensavers
- **93**: Check what's currently running

## 🎨 All Screensavers by Category

### Matrix/Rain (1-6)
- **1**: Fixed Matrix Rain ⭐ (Recommended)
- **2-6**: Original matrix variants (may have memory leaks)

### Timer (7-8)
- Long-running accumulation effects

### Water (9-10)
- Rain and water effects

### Particles (11-12)
- Micro dots and particle systems

### Fire (13-14)
- Flame and fire effects

### Retro (15-17)
- 1990s style effects

### Visual (18)
- Kaleidoscope patterns

### Fractals (19-22)
- Mathematical fractal animations

## 🛠️ Troubleshooting

### If you get "GPIO busy" errors:
```bash
./saver
# Choose 94 (Fix GPIO Conflicts)
# Then try your screensaver again
```

### If screensaver freezes:
```bash
# Stop everything
./saver
# Choose 92 (Disable All Services)

# Then setup stable version
# Choose 90 (Setup Stable Service)
```

### Check what's running:
```bash
./saver
# Choose 93 (Check Service Status)
```

### Manual service commands:
```bash
sudo systemctl status lcd-stable       # Check stable service
sudo systemctl restart lcd-stable      # Restart if needed
sudo systemctl stop lcd-stable         # Stop service
```

## 🎉 Features

- ✅ Number-based selection (no typing screensaver names)
- ✅ Test mode (30-second previews)
- ✅ Service management (auto-start on boot)
- ✅ Status checking
- ✅ Memory leak protection (option 1 & 90)
- ✅ Resource limits (prevents system issues)
- ✅ Auto-restart protection
- ✅ Easy enable/disable

**Your 15-minute freeze issue should be completely solved with options 1 + 90! 🎯**