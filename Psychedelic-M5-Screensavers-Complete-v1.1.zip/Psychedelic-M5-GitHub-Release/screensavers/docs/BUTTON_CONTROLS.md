# 🕹️ Physical Button Controls for Waveshare LCD HAT

## 🎯 Quick Setup

### Option 1: Simple Button Switcher (Recommended)
```bash
./saver
# Choose 80 (Simple Button Switcher)
```

**Controls:**
- **KEY1** (Button 1): Next screensaver →
- **KEY2** (Button 2): Previous screensaver ←  
- **KEY3** (Button 3): Exit switcher

### Option 2: Auto-Start Button Switcher
```bash
./saver  
# Choose 82 (Auto-Start Button Switcher)
```
This makes button control start automatically on boot!

## 🎮 Available Button Systems

| Option | Description | Buttons Used | Best For |
|--------|-------------|--------------|----------|
| **80** | Simple Switcher | 3 buttons only | Easy use, quick setup |
| **81** | Advanced Switcher | All buttons + joystick | Full control, more features |
| **82** | Auto-Start Service | 3 buttons (auto-boot) | Set and forget |

## 🕹️ Button Layout on LCD HAT

```
Waveshare 1.44" LCD HAT Physical Layout:

    [LCD Screen 128x128]
    
         ↑ (UP)
    ← (LEFT) ⭕ (PRESS) → (RIGHT)  
         ↓ (DOWN)
    
    [KEY1]  [KEY2]  [KEY3]
    (Pin21) (Pin20) (Pin16)
```

## 📋 Simple Button Switcher Details

### What It Does:
- Cycles through **10 best screensavers** 
- Shows current screensaver name on LCD
- Auto-restarts if screensaver crashes
- Clean exit when done

### Screensaver Order:
1. Fixed Matrix Rain (Stable) ⭐
2. Blue Matrix Rain
3. Rainbow Matrix Rain  
4. Neon Rain
5. Simple Flames
6. Plasma Field
7. Bouncing Balls
8. Kaleidoscope
9. Micro Dots
10. Raindrops

### Controls:
- **KEY1 → Next**: Cycles 1→2→3→...→10→1
- **KEY2 ← Previous**: Cycles 10→9→8→...→1→10  
- **KEY3 🚪 Exit**: Stops switcher and clears LCD

## 🔧 Advanced Button Switcher Details

### Additional Features:
- **KEY3**: Pause/Resume current screensaver
- **Joystick UP**: Jump to favorite screensavers only
- **Joystick DOWN**: Show detailed screensaver info
- **Joystick PRESS**: Exit switcher

### Favorites List:
- Fixed Matrix Rain
- Blue Matrix Rain  
- Simple Flames
- Plasma Field

## 🛠️ Management Commands

### Check if button switcher is running:
```bash
./saver
# Choose 93 (Check Service Status)
```

### Stop button switcher:
```bash
./saver
# Choose 92 (Disable All Services)
```

### Manual start (temporary):
```bash
./saver
# Choose 80 or 81
```

### Service management:
```bash
sudo systemctl status lcd-button-switcher
sudo systemctl restart lcd-button-switcher  
sudo systemctl stop lcd-button-switcher
```

## 🎯 Best Usage Scenarios

### **Scenario 1: Quick Demo**
```bash
./saver 80    # Start simple button switcher
# Press KEY1 to cycle through screensavers
# Press KEY3 to exit when done
```

### **Scenario 2: Permanent Installation** 
```bash
./saver 82    # Setup auto-start button switcher
# Now buttons work every time you boot!
```

### **Scenario 3: Kiosk Mode**
```bash
./saver 82    # Auto-start button switcher
# Visitors can press buttons to change screensavers
# System keeps running smoothly
```

## ⚡ Pro Tips

1. **Start with option 80** - easiest to understand
2. **Use option 82 for permanent setup** - boots with button control
3. **KEY1 is your friend** - just keep pressing it to browse
4. **Button response time** - 0.5 second debounce prevents spam
5. **Auto-restart protection** - if screensaver crashes, it restarts automatically
6. **LCD status display** - shows current screensaver name when switching

## 🔍 Troubleshooting

### Buttons not responding?
```bash
# Check button hardware
gpio readall | grep -E "(20|21|16)"

# Restart button service  
sudo systemctl restart lcd-button-switcher
```

### Wrong screensaver list?
Edit `simple_button_switcher.py` and modify the `self.screensavers` array.

### Want different button assignments?
Edit the GPIO pin numbers in the button switcher files.

**Your LCD HAT now has physical button controls! 🎮🎉**