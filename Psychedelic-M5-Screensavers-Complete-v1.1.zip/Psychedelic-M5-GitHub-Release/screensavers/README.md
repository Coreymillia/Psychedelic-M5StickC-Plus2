# 🖥️ Waveshare LCD HAT Screensaver System

A complete screensaver management system for the **Waveshare 1.44" LCD HAT** with physical button controls, background operation, and auto-boot capabilities.

## ✨ Features

- **22 Different Screensavers** - Matrix rain, fractals, fire effects, particles, and more
- **Physical Button Controls** - Use the LCD HAT buttons to switch screensavers
- **Background Operation** - Screensavers survive terminal closing and SSH disconnections  
- **Auto-Boot System** - Set any screensaver to start automatically on system boot
- **Memory Leak Protection** - Fixed versions prevent crashes and freezing
- **Easy Management** - Comprehensive menu system for all operations
- **GPIO Conflict Resolution** - Automatic cleanup prevents "GPIO busy" errors

## 🎮 Physical Controls

Use the buttons on your Waveshare LCD HAT:

\`\`\`
    [LCD Screen 128x128]
    
         ↑ (UP)
    ← (LEFT) ⭕ (PRESS) → (RIGHT)  
         ↓ (DOWN)
    
    [KEY1]  [KEY2]  [KEY3]
    Next ►  ◄ Prev  Exit
\`\`\`

- **KEY1** (Pin 21): Next screensaver →
- **KEY2** (Pin 20): Previous screensaver ←  
- **KEY3** (Pin 16): Exit switcher

## 🚀 Quick Start

### 1. Installation
\`\`\`bash
git clone [your-repo-url]
cd screensavers
chmod +x install.sh
./install.sh
\`\`\`

### 2. Launch Main Menu
\`\`\`bash
./saver
\`\`\`

### 3. Key Options
- **1**: Fixed Matrix Rain (recommended, memory-safe)
- **50**: Background Mode (survive terminal closing)
- **51**: Boot Manager (set any screensaver to auto-boot) ⭐
- **80**: Simple Button Switcher (physical controls)

## 🎯 Common Use Cases

### Auto-Boot Stable Screensaver
\`\`\`bash
./saver 51      # Boot Manager
# Choose 1      # Fixed Matrix Rain
# Answer 'y'    # Start now
\`\`\`

### Physical Button Controls
\`\`\`bash
./saver 51      # Boot Manager  
# Choose 80     # Button Switcher
# Press KEY1/KEY2/KEY3 on your LCD HAT!
\`\`\`

### Background Testing
\`\`\`bash
./saver 50      # Background Mode
# Choose any screensaver number
# Close terminal - it keeps running!
\`\`\`

## 🛠️ Requirements

### Hardware
- Raspberry Pi (tested on Pi 4/5)
- Waveshare 1.44" LCD HAT
- Properly connected GPIO pins

### Software  
- Python 3.7+
- PIL (Pillow)
- gpiozero
- LCD_1in44 driver (included)

## 📁 Project Structure

\`\`\`
screensavers/
├── README.md                 # This file
├── install.sh               # Installation script
├── saver                    # Main launcher script
├── screensaver_manager.py   # Main menu system
├── boot_manager.py          # Boot configuration manager
├── background_launcher.py   # Background process launcher
├── simple_button_switcher.py # 3-button physical controls
├── glyph_rain1_fixed.py     # Memory-safe matrix rain
├── gpio_cleanup.py          # GPIO conflict resolver
├── requirements.txt        # Python dependencies
├── docs/                   # Documentation
└── [22 screensaver files]  # Individual screensavers
\`\`\`

## 🔧 Management Commands

### Check Running Screensavers
\`\`\`bash
ps aux | grep -E "(glyph|screensaver)" | grep -v grep
\`\`\`

### Stop Background Screensaver
\`\`\`bash
pkill -f screensaver_name.py
# OR
./saver 96    # Disable all services
\`\`\`

## 🐛 Troubleshooting

### GPIO Busy Error
\`\`\`bash
./saver 94    # Fix GPIO Conflicts
\`\`\`

### Button Controls Don't Work
\`\`\`bash
# Check GPIO connections
gpio readall | grep -E "(20|21|16)"

# Test with debug output
./saver 80
\`\`\`

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

---

**Made with ❤️ for Raspberry Pi and LCD HAT enthusiasts**

⭐ **Star this repo if it helped you!** ⭐
